/* =====================================================
   ALPINE ASCENTS - MAIN SCRIPT
   Every feature is wrapped in its own block with a
   start and close comment so it is easy to find.
   ===================================================== */


/* =====================================================
   PRELOADER START
   ===================================================== */
const preloader = document.getElementById("preloader");

window.addEventListener("load", function () {
    // Small delay for a smooth loading experience
    setTimeout(function () {
        preloader.classList.add("hide");
    }, 900);
});
/* =====================================================
   PRELOADER CLOSE
   ===================================================== */


/* =====================================================
   NAVBAR START
   - Smooth scroll to the clicked page section
   - Highlights the active link
   - Closes the mobile menu after a click
   ===================================================== */
const navbarCollapse = document.getElementById("alpineNavbar");
const navLinks = document.querySelectorAll('.alpine-navbar .nav-link[href^="#"]:not(.dropdown-toggle)');
const dropdownLinks = document.querySelectorAll(".alpine-navbar .dropdown-item");
const moreToggle = document.getElementById("moreDropdown");

// Make the active link match the clicked or visible section
function setActiveLink(id) {
    navLinks.forEach(function (link) {
        link.classList.toggle("active", link.getAttribute("href") === "#" + id);
    });

    let inMore = false;
    dropdownLinks.forEach(function (link) {
        const match = link.getAttribute("href") === "#" + id;
        link.classList.toggle("active", match);
        if (match) inMore = true;
    });
    moreToggle.classList.toggle("active", inMore);
}

// Close the mobile menu
function closeMobileMenu() {
    if (navbarCollapse.classList.contains("show") && window.bootstrap) {
        bootstrap.Collapse.getOrCreateInstance(navbarCollapse).hide();
    }
}

// Every link that points to a section on this page (navbar, buttons, footer)
document.addEventListener("click", function (event) {
    const link = event.target.closest('a[href^="#"]');
    if (!link) return;

    const id = link.getAttribute("href").slice(1);
    const target = id ? document.getElementById(id) : null;
    if (!target) return;

    event.preventDefault();
    history.replaceState(null, "", "#" + id);

    const goToTarget = function () {
        target.scrollIntoView({ behavior: "smooth", block: "start" });
    };

    if (link.closest(".alpine-navbar")) {
        setActiveLink(id);

        // On mobile, wait for the menu to close first so the page doesn't jump
        if (navbarCollapse.classList.contains("show")) {
            navbarCollapse.addEventListener("hidden.bs.collapse", goToTarget, { once: true });
            closeMobileMenu();
            return;
        }
    }
    goToTarget();
});

// Highlight the nav link of the section currently on screen
const navSectionIds = [
    "home", "about", "expedition", "mountaineering", "clubs", "hazards",
    "sheltering", "gallery", "history", "types", "techniques", "records",
    "success-story", "development", "contact"
];

const sectionObserver = new IntersectionObserver(function (entries) {
    entries.forEach(function (entry) {
        if (entry.isIntersecting) setActiveLink(entry.target.id);
    });
}, { rootMargin: "-45% 0px -50% 0px" });

navSectionIds.forEach(function (id) {
    const section = document.getElementById(id);
    if (section) sectionObserver.observe(section);
});

// Open the right section if the page is loaded with a #link
window.addEventListener("load", function () {
    const id = location.hash.slice(1);
    const target = id && document.getElementById(id);
    if (target) setTimeout(function () { target.scrollIntoView(); }, 950);
});


// DEMO VISITOR COUNTER
// Counts visits in this browser only, not all website visitors.
const visitorElement = document.getElementById("visitorCount");
const storageKey = "alpineAscentsDemoVisits";
let visitTotal = 1247;

try {
    let visits = Number(localStorage.getItem(storageKey));
    if (!Number.isFinite(visits) || visits < 1) {
        visits = 1247;
    }
    visits++;
    localStorage.setItem(storageKey, visits);
    visitTotal = visits;
} catch (error) {
    // Keep the sample number if browser storage is unavailable.
}
visitorElement.textContent = visitTotal.toLocaleString("en-US");
/* =====================================================
   NAVBAR CLOSE
   ===================================================== */


/* =====================================================
   SHARED POPUP (MODAL) START
   One Bootstrap modal shows details for every
   "Read more / Explore / How to use" button.
   ===================================================== */
const infoModalElement = document.getElementById("infoModal");
const infoModal = new bootstrap.Modal(infoModalElement);
const infoKicker = document.getElementById("infoModalKicker");
const infoTitle = document.getElementById("infoModalTitle");
const infoBody = document.getElementById("infoModalBody");
const infoFooter = document.getElementById("infoModalFooter");

// Content for every popup, looked up by its key
const infoContent = {
    equipment: {
        kicker: "MOUNTAINEERING", title: "Essential Gear List",
        html: "<ul><li>Climbing helmet – protects against falling rock and impacts</li><li>Harness – essential for roped travel and glacier crossings</li><li>Crampons – traction on ice and steep snow</li><li>Ice axe – stability and self-arrest</li><li>Headlamp with spare batteries</li><li>GPS beacon / satellite messenger</li><li>Layered clothing: base, insulation and waterproof shell</li><li>First aid kit, sun protection and water purification</li></ul>"
    },
    tents: { kicker: "SHELTER", title: "Expedition Tents", html: "<p>Pitch on flat, compacted snow away from avalanche paths. Face the door away from the wind, bury snow anchors deeply and keep vents open to reduce condensation. Clear heavy snow from the walls during storms.</p>" },
    bivy: { kicker: "SHELTER", title: "Bivouac Sacks", html: "<p>Use a bivy for emergencies or fast, light climbs. Find a sheltered ledge, sit or lie on an insulating pad, and keep the opening slightly open for fresh air. Keep boots and water inside so they don't freeze.</p>" },
    huts: { kicker: "SHELTER", title: "Mountain Huts", html: "<p>Book ahead in busy seasons, respect quiet hours and hut rules, carry your own sleeping liner, and pack out all rubbish. Huts are shared spaces – leave them better than you found them.</p>" },
    snowcave: { kicker: "SHELTER", title: "Snow Caves", html: "<p>Dig into a deep, stable snow bank away from avalanche terrain. Build the sleeping platform higher than the entrance so warm air stays inside, and always keep a ventilation hole open.</p>" },
    igloo: { kicker: "SHELTER", title: "Igloos", html: "<p>Cut firm wind-packed snow into blocks and lay them in an inward spiral. Fill gaps with loose snow, add a small vent near the top, and build the entrance below floor level.</p>" },
    emergency: { kicker: "SHELTER", title: "Emergency Shelters", html: "<p>Carry a lightweight emergency bag or tarp. Get out of the wind, insulate yourself from the ground, stay with your group and signal for help as early as possible.</p>" },
    jessica: { kicker: "FEATURED STORY", title: "From Self-Doubt to Summit", img: "images/online-27.jpg", html: "<p>Jessica Miller had never climbed above 3,000 metres when she joined our Everest Base Camp expedition. Over 14 days she trained with our guides, learned to pace herself at altitude and found strength she didn't know she had.</p><p>“The mountains reminded me what I'm capable of. I came home a different person.” – Jessica Miller, United States</p>" },
    "news-featured": { kicker: "TECH & INNOVATION", title: "New Rescue Drones Tested on Everest", img: "images/development-2.jpg", html: "<p>High-altitude rescue drones are being explored as a way to support mountain rescue teams in difficult terrain. Equipped with navigation technology and aerial imaging, these systems may help teams assess remote areas and plan safer responses.</p>" },
    "news-k2": { kicker: "EXPEDITIONS", title: "Record Summit Season on K2", html: "<p>Favourable weather windows can create opportunities for climbing teams to attempt high mountain summits. Careful preparation, experienced guides and responsible decisions remain essential in challenging conditions.</p>" },
    "news-gps": { kicker: "GEAR & TECH", title: "Smart GPS Beacons for Climbers", html: "<p>Satellite navigation and emergency communication devices help climbers share their location in remote areas. Before an expedition, understand your device's coverage, battery needs and emergency features.</p>" },
    "news-glaciers": { kicker: "ENVIRONMENT", title: "Climate Change and Melting Glaciers", html: "<p>Mountain glaciers are important sources of freshwater for many communities. Changes in temperature and precipitation affect glacier size, local ecosystems and water availability.</p>" },
    "news-permits": { kicker: "POLICY", title: "New Permit Rules in Nepal", html: "<p>Climbing permits and local regulations help manage mountain access, safety and environmental protection. Always check the current official requirements before planning a journey.</p>" },
    "news-oxygen": { kicker: "GEAR & TECH", title: "Lightweight Oxygen Systems", html: "<p>Equipment development continues to focus on reducing pack weight and improving reliability for high-altitude expeditions.</p>" },
    "news-wildlife": { kicker: "ENVIRONMENT", title: "Protecting Mountain Wildlife", html: "<p>Mountain ecosystems support many specialised species. Responsible travel, reduced waste and respect for protected areas minimise the impact of visitors.</p>" }
};

// Open the popup with any content object
function openInfo(data, bookTrip) {
    infoKicker.textContent = data.kicker || "";
    infoTitle.textContent = data.title || "";
    infoBody.innerHTML = (data.img ? '<img src="' + data.img + '" alt="">' : "") + (data.html || "");

    // Optional "Book this expedition" button
    const oldBook = infoFooter.querySelector(".book-trip");
    if (oldBook) oldBook.remove();
    if (bookTrip) {
        const book = document.createElement("a");
        book.href = "#contact";
        book.className = "btn-cyan book-trip";
        book.textContent = "Book this expedition →";
        book.addEventListener("click", function () {
            document.getElementById("cTrip").value = bookTrip;
            infoModal.hide();
        });
        infoFooter.prepend(book);
    }
    infoModal.show();
}

// Any element with data-info="key" opens its popup
document.addEventListener("click", function (event) {
    const trigger = event.target.closest("[data-info]");
    if (!trigger) return;
    const data = infoContent[trigger.dataset.info];
    if (data) openInfo(data);
});
/* =====================================================
   SHARED POPUP (MODAL) CLOSE
   ===================================================== */


/* =====================================================
   EXPEDITION SECTION START
   ===================================================== */
const expeditions = [
    { name: "Everest Base Camp", country: "NEPAL", days: 14, level: "moderate", img: "images/aboutmountain.jpg", text: "Trek through Sherpa villages and monasteries to the foot of the world's highest mountain at 5,364 m. Includes acclimatization days in Namche Bazaar and Dingboche." },
    { name: "K2 Base Camp", country: "PAKISTAN", days: 16, level: "challenging", img: "images/base.jpg", text: "Follow the Baltoro Glacier past Trango Towers to Concordia and the base of K2 – one of the most dramatic treks on Earth." },
    { name: "Kilimanjaro", country: "TANZANIA", days: 9, level: "moderate", img: "images/online-28.jpg", text: "Climb Africa's highest peak (5,895 m) via the scenic Machame route, crossing five climate zones from rainforest to arctic summit." },
    { name: "Denali", country: "ALASKA, USA", days: 18, level: "challenging", img: "images/online-23.jpg", text: "A serious glacier expedition on North America's highest peak (6,190 m), with sled hauling, crevasse travel and extreme cold." },
    { name: "Aconcagua", country: "ARGENTINA", days: 16, level: "challenging", img: "images/ridge.jpg", text: "The highest mountain outside Asia (6,961 m). A high-altitude test of endurance through the Andes with expert acclimatization planning." },
    { name: "Mont Blanc", country: "FRANCE / ITALY", days: 7, level: "moderate", img: "images/himaliyas.jpg", text: "The classic alpine summit (4,808 m). Includes a skills course on glacier travel, crampons and ice axe before the summit push." }
];

const expGrid = document.getElementById("expGrid");
const tripSelect = document.getElementById("cTrip");

// Build expedition cards and contact form options
expeditions.forEach(function (trip, index) {
    expGrid.insertAdjacentHTML("beforeend",
        '<article class="exp-card reveal" data-level="' + trip.level + '">' +
            '<img src="' + trip.img + '" alt="' + trip.name + '" loading="lazy">' +
            '<div class="exp-body">' +
                "<h3>" + trip.name + "</h3>" +
                '<span class="exp-country">' + trip.country + "</span>" +
                '<div class="exp-meta"><span><i class="bi bi-calendar3"></i>' + trip.days + ' DAYS</span><span><i class="bi bi-triangle"></i>' + trip.level.toUpperCase() + "</span></div>" +
                '<button class="link-arrow" data-exp="' + index + '">EXPLORE →</button>' +
            "</div>" +
        "</article>"
    );
    tripSelect.insertAdjacentHTML("beforeend", "<option>" + trip.name + "</option>");
});
tripSelect.insertAdjacentHTML("beforeend", "<option>Not sure yet</option>");

// Explore button opens trip details
expGrid.addEventListener("click", function (event) {
    const button = event.target.closest("[data-exp]");
    if (!button) return;
    const trip = expeditions[button.dataset.exp];
    openInfo({
        kicker: trip.country + " · " + trip.days + " DAYS · " + trip.level.toUpperCase(),
        title: trip.name,
        img: trip.img,
        html: "<p>" + trip.text + "</p>"
    }, trip.name);
});

// Filter expeditions by difficulty
document.getElementById("expFilters").addEventListener("click", function (event) {
    const chip = event.target.closest(".chip");
    if (!chip) return;
    this.querySelectorAll(".chip").forEach(function (c) { c.classList.remove("active"); });
    chip.classList.add("active");
    expGrid.querySelectorAll(".exp-card").forEach(function (card) {
        card.style.display = chip.dataset.filter === "all" || card.dataset.level === chip.dataset.filter ? "" : "none";
    });
});
/* =====================================================
   EXPEDITION SECTION CLOSE
   ===================================================== */


/* =====================================================
   CLUBS SECTION START
   ===================================================== */
const clubs = [
    { name: "Alpine Ascents Base Camp", location: "Kathmandu, Nepal", lat: 27.7172, lng: 85.3240 },
    { name: "The Alpine Club", location: "London, UK", lat: 51.5074, lng: -0.1278 },
    { name: "American Alpine Club", location: "Golden, Colorado, USA", lat: 39.7555, lng: -105.2211 },
    { name: "Club Alpin Français", location: "Chamonix, France", lat: 45.9237, lng: 6.8694 },
    { name: "Alpine Club of Pakistan", location: "Islamabad, Pakistan", lat: 33.6844, lng: 73.0479 }
];

const clubList = document.getElementById("clubList");
const mapFrame = document.getElementById("mapFrame");
const selectedName = document.getElementById("selectedName");
const selectedLocation = document.getElementById("selectedLocation");
const selectedCoordinates = document.getElementById("selectedCoordinates");
const googleMapsLink = document.getElementById("googleMapsLink");
const myLocationBtn = document.getElementById("myLocationBtn");
const locationMessage = document.getElementById("locationMessage");

// Build club buttons
clubs.forEach(function (club, index) {
    clubList.insertAdjacentHTML("beforeend",
        '<button class="club-item" type="button" data-index="' + index + '">' +
            '<span class="club-name">' + club.name + "</span>" +
            '<span class="club-location"><i class="bi bi-geo-alt"></i> ' + club.location + "</span>" +
        "</button>"
    );
});

// Move the map to a place
function showOnMap(name, location, lat, lng) {
    mapFrame.src = "https://maps.google.com/maps?q=" + lat + "," + lng + "&z=12&output=embed";
    googleMapsLink.href = "https://www.google.com/maps?q=" + lat + "," + lng;
    selectedName.textContent = name;
    selectedLocation.textContent = location;
    selectedCoordinates.textContent =
        "Latitude " + Math.abs(lat).toFixed(4) + (lat >= 0 ? " N" : " S") +
        " · Longitude " + Math.abs(lng).toFixed(4) + (lng >= 0 ? " E" : " W");
}

// Select a club from the list
function selectClub(index) {
    const club = clubs[index];
    clubList.querySelectorAll(".club-item").forEach(function (item) {
        item.classList.toggle("active", Number(item.dataset.index) === index);
    });
    showOnMap(club.name, club.location, club.lat, club.lng);
}

clubList.addEventListener("click", function (event) {
    const item = event.target.closest(".club-item");
    if (item) selectClub(Number(item.dataset.index));
});

// Show the visitor's current location on the map
myLocationBtn.addEventListener("click", function () {
    if (!navigator.geolocation) {
        locationMessage.textContent = "Location is not supported by your browser.";
        return;
    }
    locationMessage.textContent = "Finding your location…";
    navigator.geolocation.getCurrentPosition(
        function (position) {
            clubList.querySelectorAll(".club-item").forEach(function (item) { item.classList.remove("active"); });
            showOnMap("Your Location", "Shown on the map", position.coords.latitude, position.coords.longitude);
            locationMessage.textContent = "Your location is now shown on the map.";
        },
        function () {
            locationMessage.textContent = "Could not get your location. Please allow location access.";
        }
    );
});

selectClub(0);
/* =====================================================
   CLUBS SECTION CLOSE
   ===================================================== */


/* =====================================================
   HAZARDS SECTION START (safety checklist progress)
   ===================================================== */
const checklistBoxes = document.querySelectorAll("#safetyChecklist input");
const checkCount = document.getElementById("checkCount");
const checkFill = document.getElementById("checkFill");

function updateChecklist() {
    let done = 0;
    checklistBoxes.forEach(function (box) {
        box.closest(".check-item").classList.toggle("done", box.checked);
        if (box.checked) done++;
    });
    checkCount.textContent = done === checklistBoxes.length
        ? "All set – you're ready to climb!"
        : done + " / " + checklistBoxes.length + " ready";
    checkFill.style.width = (done / checklistBoxes.length) * 100 + "%";
}

checklistBoxes.forEach(function (box) {
    box.addEventListener("change", updateChecklist);
});
/* =====================================================
   HAZARDS SECTION CLOSE
   ===================================================== */


/* =====================================================
   GALLERY SECTION START
   - Filters, lightbox popup, video links
   ===================================================== */
const photoCards = Array.from(document.querySelectorAll(".photo-card"));
const videoCards = document.querySelectorAll(".video-card");
const videoBlock = document.getElementById("videoBlock");
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const lightboxCaption = document.getElementById("lightboxCaption");
let visiblePhotos = photoCards;
let currentPhoto = 0;

// Gallery filter buttons
document.getElementById("galleryFilters").addEventListener("click", function (event) {
    const chip = event.target.closest(".chip");
    if (!chip) return;
    const filter = chip.dataset.filter;

    this.querySelectorAll(".chip").forEach(function (c) { c.classList.remove("active"); });
    chip.classList.add("active");

    photoCards.forEach(function (card) {
        card.classList.toggle("hidden", filter !== "all" && !card.dataset.category.includes(filter));
    });

    let anyVideo = false;
    videoCards.forEach(function (card) {
        const show = filter === "all" || card.dataset.category.includes(filter);
        card.classList.toggle("hidden", !show);
        if (show) anyVideo = true;
    });
    videoBlock.style.display = anyVideo ? "" : "none";

    visiblePhotos = photoCards.filter(function (card) { return !card.classList.contains("hidden"); });
});

// Show one photo in the lightbox
function showPhoto(index) {
    currentPhoto = (index + visiblePhotos.length) % visiblePhotos.length;
    const card = visiblePhotos[currentPhoto];
    lightboxImage.src = card.querySelector("img").src;
    lightboxImage.alt = card.querySelector("img").alt;
    lightboxCaption.textContent = card.querySelector(".photo-title").textContent + " · " + card.querySelector(".photo-location").textContent;
}

function openLightbox(card) {
    showPhoto(visiblePhotos.indexOf(card));
    lightbox.classList.add("open");
    lightbox.setAttribute("aria-hidden", "false");
}

function closeLightbox() {
    lightbox.classList.remove("open");
    lightbox.setAttribute("aria-hidden", "true");
}

photoCards.forEach(function (card) {
    card.addEventListener("click", function () { openLightbox(card); });
});

document.getElementById("lightboxClose").addEventListener("click", closeLightbox);
document.getElementById("lightboxPrev").addEventListener("click", function () { showPhoto(currentPhoto - 1); });
document.getElementById("lightboxNext").addEventListener("click", function () { showPhoto(currentPhoto + 1); });

// Close when clicking the dark background
lightbox.addEventListener("click", function (event) {
    if (event.target === lightbox) closeLightbox();
});

// Keyboard navigation
document.addEventListener("keydown", function (event) {
    if (!lightbox.classList.contains("open")) return;
    if (event.key === "Escape") closeLightbox();
    if (event.key === "ArrowLeft") showPhoto(currentPhoto - 1);
    if (event.key === "ArrowRight") showPhoto(currentPhoto + 1);
});

// Video thumbnails open a YouTube search in a new tab
document.querySelectorAll(".video-thumbnail").forEach(function (button) {
    button.addEventListener("click", function () {
        window.open("https://www.youtube.com/results?search_query=" + encodeURIComponent(button.dataset.search), "_blank", "noopener");
    });
});
/* =====================================================
   GALLERY SECTION CLOSE
   ===================================================== */


/* =====================================================
   CLIMBING STYLES (TYPES) SECTION START
   ===================================================== */
const climbingStyles = [
    { kicker: "SPEED / SKILL / SELF-RELIANCE", title: "Alpine Style", level: "advanced", img: "images/online-2.jpg", short: "Lightweight, fast and self-sufficient. Alpine style emphasizes minimal gear, efficient movement and real-time decision making.", long: "Alpine-style climbing focuses on moving efficiently with a relatively lightweight team and limited equipment. Good planning, mountain awareness, technical ability and sound decisions are essential." },
    { kicker: "PLANNING / TEAMWORK / ENDURANCE", title: "Expedition Style", level: "challenging", img: "images/online-4.jpg", short: "A methodical approach to big objectives with larger teams, extensive logistics and sustained time in remote places.", long: "Expedition climbing involves careful preparation, teamwork, planned camps and logistics over an extended period. It is often used for remote mountains and longer objectives." },
    { kicker: "ICE / TECHNIQUE / PRECISION", title: "Ice Climbing", level: "intermediate", img: "images/style-1.jpg", short: "Vertical frozen terrain demands focus and technical skill, from alpine ice to frozen waterfalls.", long: "Ice climbing involves travelling on frozen waterfalls, ice formations or alpine ice using specialised equipment. Training and qualified supervision are important for beginners." },
    { kicker: "MOVEMENT / STRENGTH / EXPOSURE", title: "Rock Climbing", level: "varies", img: "images/style-2.jpg", short: "From alpine ridges to big walls, rock climbing builds technical skills and mental resilience.", long: "Rock climbing combines movement, balance, problem-solving and technique on natural rock. Climbers learn route selection, equipment checks and safety systems with qualified instruction." },
    { kicker: "SKI / CLIMB / DESCEND", title: "Ski Mountaineering", level: "intermediate", img: "images/style-3.jpg", short: "Earn your turns. Ski mountaineering blends uphill travel and downhill adventure.", long: "Ski mountaineering combines mountain travel with skiing on snow-covered terrain. Participants need skiing skills, knowledge of mountain conditions and professional guidance for winter hazards." },
    { kicker: "JOURNEY / CULTURE / DISCOVERY", title: "Trekking", level: "beginner", img: "images/online-13.jpg", short: "Go farther, see more. A slower pace, deeper cultural connections and unforgettable landscapes.", long: "Trekking is a way to explore mountain trails, landscapes and local cultures at a walking pace. Choosing an appropriate route and checking the weather make a trip more enjoyable." }
];

const styleList = document.getElementById("styleList");

climbingStyles.forEach(function (style, index) {
    styleList.insertAdjacentHTML("beforeend",
        '<article class="style-row reveal">' +
            '<div class="style-image"><img src="' + style.img + '" alt="' + style.title + '" loading="lazy"><span class="image-number">0' + (index + 1) + " / 0" + climbingStyles.length + "</span></div>" +
            '<div class="style-copy">' +
                '<span class="style-kicker">' + style.kicker + "</span>" +
                "<h3>" + style.title + "</h3>" +
                "<p>" + style.short + "</p>" +
                '<div class="style-bottom"><span class="difficulty ' + style.level + '">' + style.level.toUpperCase() + '</span><button class="link-arrow" data-style="' + index + '">LEARN MORE →</button></div>' +
            "</div>" +
        "</article>"
    );
});

styleList.addEventListener("click", function (event) {
    const button = event.target.closest("[data-style]");
    if (!button) return;
    const style = climbingStyles[button.dataset.style];
    openInfo({
        kicker: style.kicker,
        title: style.title,
        img: style.img,
        html: "<p>" + style.long + "</p><p><i class='bi bi-exclamation-triangle'></i> Always prepare carefully and seek qualified guidance for mountain activities.</p>"
    });
});
/* =====================================================
   CLIMBING STYLES (TYPES) SECTION CLOSE
   ===================================================== */


/* =====================================================
   TECHNIQUES SECTION START
   ===================================================== */
const techniques = [
    { icon: "bi-link-45deg", title: "Rope Work & Knots", short: "Essential knots, rope management and systems.", long: "Learn the figure-eight follow-through, clove hitch, prusik and Munter hitch. Practise coiling, flaking and managing ropes so they never tangle when it matters." },
    { icon: "bi-shield-check", title: "Belaying", short: "Belay techniques to climb and descend with control.", long: "A belayer controls the rope to catch a falling climber. Always do partner checks, keep a brake hand on the rope and communicate with clear calls." },
    { icon: "bi-hammer", title: "Ice Axe Self-Arrest", short: "Stop a fall on snow and ice.", long: "Roll onto your stomach, drive the pick into the snow beside your shoulder, press your body weight onto the axe and lift your feet if wearing crampons." },
    { icon: "bi-snow", title: "Crampon Technique", short: "Secure footwork on steep snow and ice.", long: "Use flat-footing (French technique) on moderate slopes and front-pointing on steep ice. Walk with feet slightly apart to avoid catching your trousers." },
    { icon: "bi-arrow-down-circle", title: "Rappelling", short: "Safe, controlled descents in alpine terrain.", long: "Check anchors, tie stopper knots in rope ends and use a friction hitch backup. Descend smoothly with feet apart and body leaning back." },
    { icon: "bi-snow2", title: "Glacier Travel", short: "Rope travel and crevasse rescue basics.", long: "Travel roped at even spacing, keep the rope taut, probe suspicious snow bridges and practise a pulley system for crevasse rescue." },
    { icon: "bi-heart-pulse", title: "Acclimatization", short: "Strategies for high-altitude success.", long: "Climb high, sleep low. Above 3,000 m raise your sleeping altitude slowly, rest every few days, drink plenty and descend if symptoms worsen." },
    { icon: "bi-compass", title: "Navigation", short: "Map, compass and GPS skills.", long: "Learn to read contour lines, take a bearing and follow it in poor visibility. Carry a GPS with spare batteries, but never rely on a single device." }
];

const techGrid = document.getElementById("techGrid");

techniques.forEach(function (tech, index) {
    techGrid.insertAdjacentHTML("beforeend",
        '<button class="tech-card reveal" type="button" data-tech="' + index + '">' +
            '<i class="bi ' + tech.icon + '"></i>' +
            "<h3>" + tech.title + "</h3>" +
            "<p>" + tech.short + "</p>" +
            "<span>→</span>" +
        "</button>"
    );
});

techGrid.addEventListener("click", function (event) {
    const card = event.target.closest("[data-tech]");
    if (!card) return;
    const tech = techniques[card.dataset.tech];
    openInfo({ kicker: "TECHNIQUE", title: tech.title, html: "<p>" + tech.long + "</p>" });
});
/* =====================================================
   TECHNIQUES SECTION CLOSE
   ===================================================== */


/* =====================================================
   RECORDS SECTION START
   - Eight-thousanders table with search, filter and sort
   ===================================================== */
const peaks = [
    { rank: 1, name: "Mount Everest", height: 8848, location: "Nepal / China", year: 1953 },
    { rank: 2, name: "K2", height: 8611, location: "Pakistan / China", year: 1954 },
    { rank: 3, name: "Kangchenjunga", height: 8586, location: "Nepal / India", year: 1955 },
    { rank: 4, name: "Lhotse", height: 8516, location: "Nepal / China", year: 1956 },
    { rank: 5, name: "Makalu", height: 8485, location: "Nepal / China", year: 1955 },
    { rank: 6, name: "Cho Oyu", height: 8188, location: "Nepal / China", year: 1954 },
    { rank: 7, name: "Dhaulagiri I", height: 8167, location: "Nepal", year: 1960 },
    { rank: 8, name: "Manaslu", height: 8163, location: "Nepal", year: 1956 },
    { rank: 9, name: "Nanga Parbat", height: 8126, location: "Pakistan", year: 1953 },
    { rank: 10, name: "Annapurna I", height: 8091, location: "Nepal", year: 1950 },
    { rank: 11, name: "Gasherbrum I", height: 8080, location: "Pakistan / China", year: 1958 },
    { rank: 12, name: "Broad Peak", height: 8051, location: "Pakistan / China", year: 1957 },
    { rank: 13, name: "Gasherbrum II", height: 8035, location: "Pakistan / China", year: 1956 },
    { rank: 14, name: "Shishapangma", height: 8027, location: "China", year: 1964 }
];

const peakBody = document.querySelector("#peaksTable tbody");
const peakSearch = document.getElementById("peakSearch");
const peakCountry = document.getElementById("peakCountry");
let sortKey = "rank";
let sortAsc = true;

function renderPeaks() {
    const text = peakSearch.value.trim().toLowerCase();
    const country = peakCountry.value;

    const rows = peaks
        .filter(function (p) {
            return (p.name + " " + p.location).toLowerCase().includes(text) &&
                (!country || p.location.includes(country));
        })
        .sort(function (a, b) {
            const result = a[sortKey] > b[sortKey] ? 1 : a[sortKey] < b[sortKey] ? -1 : 0;
            return sortAsc ? result : -result;
        });

    peakBody.innerHTML = rows.length
        ? rows.map(function (p) {
            return "<tr><td>" + p.rank + "</td><td>" + p.name + "</td><td>" + p.height.toLocaleString("en-US") + "</td><td>" + p.location + "</td><td>" + p.year + "</td></tr>";
        }).join("")
        : '<tr><td colspan="5">No mountains match your search.</td></tr>';
}

document.querySelectorAll("#peaksTable th").forEach(function (th) {
    th.addEventListener("click", function () {
        sortAsc = sortKey === th.dataset.key ? !sortAsc : true;
        sortKey = th.dataset.key;
        renderPeaks();
    });
});

peakSearch.addEventListener("input", renderPeaks);
peakCountry.addEventListener("change", renderPeaks);
renderPeaks();
/* =====================================================
   RECORDS SECTION CLOSE
   ===================================================== */


/* =====================================================
   SUCCESS STORY SECTION START
   - View all stories + counting numbers
   ===================================================== */
const storyWrap = document.getElementById("storyWrap");
const viewStories = document.getElementById("viewStories");

viewStories.addEventListener("click", function () {
    const open = storyWrap.classList.toggle("show-all");
    viewStories.textContent = open ? "Show Fewer Stories ↑" : "View All Stories →";
});

// Count numbers up when they appear on screen
const counterObserver = new IntersectionObserver(function (entries, observer) {
    entries.forEach(function (entry) {
        if (!entry.isIntersecting) return;
        const el = entry.target;
        const target = Number(el.dataset.target);
        const suffix = el.dataset.suffix || "";
        const start = performance.now();

        function tick(now) {
            const progress = Math.min((now - start) / 1500, 1);
            el.textContent = Math.round(target * progress).toLocaleString("en-US") + suffix;
            if (progress < 1) requestAnimationFrame(tick);
        }
        requestAnimationFrame(tick);
        observer.unobserve(el);
    });
}, { threshold: 0.5 });

document.querySelectorAll(".counter").forEach(function (el) { counterObserver.observe(el); });
/* =====================================================
   SUCCESS STORY SECTION CLOSE
   ===================================================== */


/* =====================================================
   LATEST DEVELOPMENT SECTION START
   - View all news, live Nepal time, newsletter
   ===================================================== */
const newsWrap = document.getElementById("newsWrap");
const viewNews = document.getElementById("viewNews");

viewNews.addEventListener("click", function () {
    const open = newsWrap.classList.toggle("show-all");
    viewNews.textContent = open ? "Show less ↑" : "View all news →";
});

// Today's date and the current time in Nepal
function updateClock() {
    const now = new Date();
    document.getElementById("todayDate").textContent =
        now.toLocaleDateString("en-US", { month: "short", day: "numeric", year: "numeric" }).toUpperCase();
    document.getElementById("nepalTime").textContent =
        now.toLocaleTimeString("en-GB", { timeZone: "Asia/Kathmandu", hour: "2-digit", minute: "2-digit" });
}
updateClock();
setInterval(updateClock, 30000);
document.getElementById("visitCount2").textContent = visitTotal.toLocaleString("en-US");

// Newsletter form
const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;

document.getElementById("newsletterForm").addEventListener("submit", function (event) {
    event.preventDefault();
    const input = document.getElementById("newsletterEmail");
    const message = document.getElementById("newsletterMessage");

    if (!emailPattern.test(input.value.trim())) {
        message.textContent = "Please enter a valid email address.";
        return;
    }
    message.textContent = "Thank you! You're subscribed.";
    input.value = "";
});
/* =====================================================
   LATEST DEVELOPMENT SECTION CLOSE
   ===================================================== */


/* =====================================================
   CONTACT SECTION START
   - Checks every field before sending
   ===================================================== */
const contactForm = document.getElementById("contactForm");
const formSuccess = document.getElementById("formSuccess");

// Show or clear an error under a field
function setError(field, text) {
    field.classList.toggle("invalid", Boolean(text));
    field.parentElement.querySelector(".error").textContent = text;
    return !text;
}

contactForm.addEventListener("submit", function (event) {
    event.preventDefault();
    formSuccess.textContent = "";

    const name = document.getElementById("cName");
    const email = document.getElementById("cEmail");
    const phone = document.getElementById("cPhone");
    const trip = document.getElementById("cTrip");
    const message = document.getElementById("cMessage");

    const valid = [
        setError(name, name.value.trim().length < 2 ? "Please enter your name." : ""),
        setError(email, !emailPattern.test(email.value.trim()) ? "Please enter a valid email." : ""),
        setError(phone, phone.value && !/^[+\d\s()-]{7,}$/.test(phone.value) ? "Please enter a valid phone number." : ""),
        setError(trip, !trip.value ? "Please choose an expedition." : ""),
        setError(message, message.value.trim().length < 10 ? "Message should be at least 10 characters." : "")
    ].every(Boolean);

    if (!valid) return;

    formSuccess.textContent = "Thank you, " + name.value.trim() + "! We'll reply about " + trip.value + " within 24 hours.";
    contactForm.reset();
});
/* =====================================================
   CONTACT SECTION CLOSE
   ===================================================== */


/* =====================================================
   REVEAL ON SCROLL START
   ===================================================== */
const revealObserver = new IntersectionObserver(function (entries, observer) {
    entries.forEach(function (entry) {
        if (entry.isIntersecting) {
            entry.target.classList.add("visible");
            observer.unobserve(entry.target);
        }
    });
}, { threshold: 0.12 });

document.querySelectorAll(".reveal").forEach(function (el) { revealObserver.observe(el); });

document.getElementById("year").textContent = new Date().getFullYear();
/* =====================================================
   REVEAL ON SCROLL CLOSE
   ===================================================== */


/* =====================================================
   SCROLL TOP / DOWN BUTTONS START
   ===================================================== */
const scrollTopBtn = document.getElementById("scrollTopBtn");
const scrollDownBtn = document.getElementById("scrollDownBtn");

// Scroll to top
scrollTopBtn.addEventListener("click", function () {
    window.scrollTo({ top: 0, behavior: "smooth" });
});

// Scroll to the next main section
scrollDownBtn.addEventListener("click", function () {
    const next = navSectionIds
        .map(function (id) { return document.getElementById(id); })
        .find(function (section) { return section && section.getBoundingClientRect().top > 100; });

    if (next) {
        next.scrollIntoView({ behavior: "smooth", block: "start" });
    } else {
        window.scrollBy({ top: window.innerHeight * 0.8, behavior: "smooth" });
    }
});

// Show or hide scroll buttons
function toggleScrollButtons() {
    scrollTopBtn.style.display = window.scrollY > 200 ? "flex" : "none";
    scrollDownBtn.style.display =
        window.innerHeight + window.scrollY >= document.documentElement.scrollHeight - 50 ? "none" : "flex";
}
window.addEventListener("scroll", toggleScrollButtons);
toggleScrollButtons();
/* =====================================================
   SCROLL TOP / DOWN BUTTONS CLOSE
   ===================================================== */
